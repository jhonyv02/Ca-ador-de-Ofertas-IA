import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
export async function serverClient() {
  const cookieStore = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {cookies:{
      getAll() { return cookieStore.getAll(); },
      setAll(toSet) { try { toSet.forEach(({name,value,options})=>cookieStore.set(name,value,options)); } catch { /* renderização server; autenticação renovada por rotas*/ } }
    }}
  );
}
